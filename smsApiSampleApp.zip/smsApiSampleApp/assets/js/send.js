function send(){
var xmlhttp = new XMLHttpRequest();
var endPoint = "https://apex.oracle.com/pls/apex/smsapi/api/send?";
    var sms= document.getElementById("sms").value;
    var sub = document.getElementById("sub").value;
    var to = document.getElementById("tel").value;
var url = endPoint+'num='+to+'&msg='+sms+'&sub='+sub;

    xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
   
   console.log('Mensaje enviado');
        
        location.reload();
     
    }
    };
xmlhttp.open("GET", url, true);
xmlhttp.send();
 
    
};